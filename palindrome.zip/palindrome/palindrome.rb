require_relative 'palindrome_test'

def question
  puts "Enter a word"
  @word = gets.strip
  Palindrome
end


question


